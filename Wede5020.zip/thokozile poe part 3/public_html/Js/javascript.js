<script>
(function () {
    "use strict";

    // 1. Mobile Navigation Toggle
    var toggleBtn = document.getElementById('nav-toggle');
    var navMenu = document.getElementById('nav-menu');

    if (toggleBtn && navMenu) {
        toggleBtn.addEventListener('click', function () {
            var isOpen = navMenu.classList.toggle('open');
            toggleBtn.classList.toggle('open', isOpen);
            toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navMenu.classList.remove('open');
                toggleBtn.classList.remove('open');
                toggleBtn.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // 2. Sticky Header & Back-to-Top Visibility on Scroll
    var header = document.getElementById('site-header');
    var backToTop = document.getElementById('back-to-top');

    function onScroll() {
        var scrolled = window.scrollY > 40;
        if (header) header.classList.toggle('scrolled', scrolled);
        if (backToTop) backToTop.classList.toggle('visible', window.scrollY > 500);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 3. Contact Form Submission Handler (for contact.html)
    var contactForm = document.getElementById('contact-form');
    var contactStatus = document.getElementById('form-status');
    if (contactForm && contactStatus) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            contactStatus.classList.add('visible');
            contactForm.reset();
        });
    }

    // 4. Enrollment Form Submission Handler (for enroll.html)
    var enrollForm = document.getElementById('enroll-form');
    var enrollStatus = document.getElementById('form-status');
    if (enrollForm && enrollStatus) {
        enrollForm.addEventListener('submit', function (e) {
            e.preventDefault();
            enrollStatus.classList.add('visible');
            enrollForm.reset();
        });
    }
})();
</script>

